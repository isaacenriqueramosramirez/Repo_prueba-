import { STUDENT } from '../data/student';

// Custom hook: entrega los datos del estudiante a la UI.
export default function useStudentInfo() {
  return STUDENT;
}
