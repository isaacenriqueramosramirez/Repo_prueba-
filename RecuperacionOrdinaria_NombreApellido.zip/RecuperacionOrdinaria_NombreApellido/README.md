# Recuperación Ordinaria – Módulo 5: Desarrollo de componentes para dispositivos móviles

- **Nombre del estudiante:** Nombre Apellido
- **Carnet:** 00000000
- **Video demostrativo (público):** PEGA_AQUI_EL_ENLACE
- **Descarga del APK:** PEGA_AQUI_EL_ENLACE

## Descripción

App móvil en React Native con Expo y React Navigation.

- **Pantalla 1:** card con la información del estudiante, logo del colegio y botón para ir a la pantalla 2.
- **Pantalla 2:** lista de shows de `https://api.tvmaze.com/shows` (nombre, géneros, fecha de inicio y fin, imagen y resumen).

## Estructura

```
src/
  components/   Card, AppButton, Loading, ErrorMessage, StudentCard, ShowCard
  hooks/        useShows (consumo de la API), useStudentInfo
  screens/      StudentScreen, ShowsScreen
  navigation/   AppNavigator
  data/         student.js
```

## Ejecutar

```
npm install
npx expo install --fix
npx expo start
```

## Generar el APK

```
npm install -g eas-cli
eas login
eas build -p android --profile preview
```
